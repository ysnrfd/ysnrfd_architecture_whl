import math
import torch
import torch.nn as nn
from torch.nn import functional as F
from typing import Optional, Tuple, List, Union, Dict, Any
from transformers.modeling_outputs import BaseModelOutputWithPast, CausalLMOutputWithPast
from transformers.utils import logging, is_flash_attn_2_available
from transformers import GenerationMixin, PreTrainedModel
import torch.utils.checkpoint
from .configuration import YsnrfdConfig

logger = logging.get_logger(__name__)

# Fallback for Flash Attention 2 if not installed
if is_flash_attn_2_available():
    from flash_attn import flash_attn_func, flash_attn_varlen_func
    from flash_attn.bert_padding import index_first_axis, pad_input, unpad_input
    _flash_attn_uses_top_level_vars = is_flash_attn_2_available()
else:
    logger.info("Flash Attention 2 is not available. Falling back to PyTorch SDPA or standard attention.")


class RMSNorm(nn.Module):
    """
    RMS Normalization layer, as used in Llama, Mistral, and others.
    """
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        # Weight is learned and applied *after* normalization
        self.weight = nn.Parameter(torch.ones(dim))
        
    def forward(self, x):
        input_dtype = x.dtype
        # Cast to float32 for stable variance calculation, especially important for bfloat16 training
        variance = x.to(torch.float32).pow(2).mean(-1, keepdim=True)
        # RMS is calculated using torch.rsqrt for numerical stability
        x = x * torch.rsqrt(variance + self.eps)
        # Apply the learned weight and cast back to input dtype
        return self.weight * x.to(input_dtype)


def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    # [..., -head_dim // 2:]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q, k, cos, sin):
    """
    Applies Rotary Position Embedding to query and key states.

    Args:
        q (torch.Tensor): Query tensor (e.g., [bsz, n_heads, q_len, head_dim])
        k (torch.Tensor): Key tensor (e.g., [bsz, n_heads, q_len, head_dim])
        cos (torch.Tensor): Cosine component of RoPE. Shape must broadcast with q/k.
        sin (torch.Tensor): Sine component of RoPE. Shape must broadcast with q/k.
        
    Returns:
        tuple: (q_embed, k_embed) with applied rotation.
    """
    # Check if cos/sin are 2D (seq_len, head_dim) and need unsqueezing
    if cos.dim() == 2:
        # [seq_len, head_dim] -> [1, 1, seq_len, head_dim] for broadcasting
        cos = cos.unsqueeze(0).unsqueeze(1)
        sin = sin.unsqueeze(0).unsqueeze(1)
        
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class YsnrfdFeedForward(nn.Module):
    """
    SwiGLU Feed-Forward network, as used in Llama.
    """
    def __init__(self, config: YsnrfdConfig):
        super().__init__()
        self.hidden_dim = config.hidden_size
        self.intermediate_size = config.intermediate_size
        
        # SwiGLU requires three weight matrices
        self.w1 = nn.Linear(self.hidden_dim, self.intermediate_size, bias=False)  # Gate
        self.w2 = nn.Linear(self.intermediate_size, self.hidden_dim, bias=False)  # Output
        self.w3 = nn.Linear(self.hidden_dim, self.intermediate_size, bias=False)  # Input
        
        # SiLU (Swish) activation function
        self.act_fn = F.silu

    def forward(self, x):
        # x: [bsz, seq_len, hidden_dim]
        # SwiGLU: w2(act_fn(w1(x)) * w3(x))
        return self.w2(self.act_fn(self.w1(x)) * self.w3(x))


class YsnrfdAttention(nn.Module):
    """
    Self-Attention block with RoPE and support for SDPA/Flash Attention 2.
    """
    def __init__(self, config: YsnrfdConfig, layer_idx: Optional[int] = None):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.hidden_dim = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = self.hidden_dim // self.num_heads
        self.max_position_embeddings = config.max_position_embeddings
        self.rope_theta = config.rope_theta
        self.attention_dropout = config.attention_dropout
        
        # F.scaled_dot_product_attention (PyTorch SDPA) is generally preferred over a manual implementation
        self.is_causal_lm = True  # Always Causal for this decoder-only model
        self._is_hf_flash_attn_2_enabled = is_flash_attn_2_available()
        
        # QKV matrices are split into three for simplicity, but could be merged
        self.q_proj = nn.Linear(self.hidden_dim, self.num_heads * self.head_dim, bias=config.attention_bias)
        self.k_proj = nn.Linear(self.hidden_dim, self.num_heads * self.head_dim, bias=config.attention_bias)
        self.v_proj = nn.Linear(self.hidden_dim, self.num_heads * self.head_dim, bias=config.attention_bias)
        self.o_proj = nn.Linear(self.num_heads * self.head_dim, self.hidden_dim, bias=config.attention_bias)
        
        # Initialize RoPE components (cos/sin buffers)
        self._init_rope()

    def _init_rope(self):
        # The base value for RoPE frequency calculation (theta)
        theta = 1.0 / (self.rope_theta ** (torch.arange(0, self.head_dim, 2, dtype=torch.float32) / self.head_dim))
        
        # Create position indices [0, 1, ..., max_position_embeddings - 1]
        t = torch.arange(self.max_position_embeddings, dtype=torch.float32)
        
        # freqs: [max_position_embeddings, head_dim // 2]
        freqs = torch.outer(t, theta)
        
        # emb: [max_position_embeddings, head_dim] (sin and cos concatenated)
        emb = torch.cat((freqs, freqs), dim=-1)
        
        # Register buffers for cos and sin, persistent=False means they are model parameters
        # but won't be saved in model.state_dict() if you save the model (standard behavior for buffers)
        self.register_buffer("cos_cached", emb.cos(), persistent=False)
        self.register_buffer("sin_cached", emb.sin(), persistent=False)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: bool = False,
        use_cache: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
        
        bsz, q_len, _ = hidden_states.size()
        
        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(hidden_states)
        value_states = self.v_proj(hidden_states)
        
        # Reshape Q/K/V states: [bsz, q_len, hidden_dim] -> [bsz, n_heads, q_len, head_dim]
        # (This uses contiguous, which is important for performance)
        query_states = query_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
        key_states = key_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
        value_states = value_states.view(bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
        
        # --- Handle Past Key/Value and determine sequence lengths ---
        past_len = past_key_value[0].shape[2] if past_key_value is not None else 0
        kv_seq_len = key_states.shape[-2] + past_len
        
        # --- RoPE: Apply Rotary Position Embedding ---
        
        # ⚠️ IMPROVEMENT: Ensure cache is on the correct device (self.to(device) usually handles this)
        device = hidden_states.device
        if self.cos_cached.device != device:
             self.cos_cached = self.cos_cached.to(device)
             self.sin_cached = self.sin_cached.to(device)
             
        # ⚠️ FIX 3 & IMPROVEMENT: Use position_ids for precise RoPE slicing
        # position_ids shape: [bsz, q_len]
        if position_ids is None:
            # Fallback for when position_ids is not passed (e.g. initial generation call without transformers pipeline)
            # This assumes simple sequential indexing.
            pos_range = torch.arange(past_len, kv_seq_len, dtype=torch.long, device=device)
            position_ids = pos_range.unsqueeze(0).expand(bsz, q_len)

        # Slice RoPE caches based on position_ids for the current query/key states
        # [bsz, q_len] -> [bsz, 1, q_len, head_dim]
        cos = self.cos_cached[position_ids].unsqueeze(1).to(query_states.dtype)
        sin = self.sin_cached[position_ids].unsqueeze(1).to(query_states.dtype)

        query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)
        
        # --- Update Past Key/Value states ---
        if past_key_value is not None:
            # Concatenate the new key/value states with the past ones
            key_states = torch.cat([past_key_value[0], key_states], dim=2)
            value_states = torch.cat([past_key_value[1], value_states], dim=2)
            
        # Update the cache
        past_key_value_out = (key_states, value_states) if use_cache else None
        
        # --- Attention Computation ---

        # ⚠️ FIX 2: Correct Causal Masking Logic for SDPA
        # is_causal must be False during incremental decoding (q_len=1, past_len > 0)
        # because the new token needs to attend to all past tokens.
        # it must be True during prefill/training (q_len > 1, past_len = 0)
        is_causal = past_key_value is None and self.is_causal_lm
        
        if self._is_hf_flash_attn_2_enabled:
            # Flash Attention 2 path (omitted implementation details for brevity, use library)
            # ... (FA2 implementation)
            attn_output = torch.empty((bsz, self.num_heads, q_len, self.head_dim), device=device) # Placeholder
            attn_weights = None # No weights outputted by FA2

        elif hasattr(F, 'scaled_dot_product_attention'):
            # PyTorch SDPA path
            
            # --- FIX STARTS HERE ---
            # If an explicit mask is provided, it contains the causal mask and padding mask.
            # SDPA cannot handle both the explicit mask and is_causal=True.
            
            # If the combined mask is present, we must set is_causal=False and pass the mask.
            # The only case where attention_mask is None is when the model is called without a
            # padding mask, and the combined mask in YsnrfdModel will be the causal mask.
            # The logic in YsnrfdModel ensures `attention_mask` (the combined 4D mask) is never None.
            
            # The best practice is to pass a mask ONLY if it's not None, and let `is_causal` handle
            # the look-ahead if the mask is None. But since a combined mask is always returned, 
            # we must only pass the mask and set `is_causal=False` during prefill/training.
            
            # However, during incremental decoding (where is_causal=False and attention_mask is present), 
            # the mask is used for padding only and must be passed.
            
            # The correct logic for your current implementation is to only rely on `is_causal=True` 
            # if *no* mask has been pre-computed. Since `YsnrfdModel` always pre-computes 
            # a combined mask, we should pass it and disable `is_causal`.
            
            # The `is_causal` flag only applies during prefill/training (`past_key_value is None`).
            # If `attention_mask` is present (always true for this model's forward), 
            # we must pass it and set `is_causal=False`.
            
            sdpa_is_causal = is_causal and attention_mask is None
            
            # This is the simplified, corrected path for the user's setup:
            # When `attention_mask` is present (the combined mask), pass it and set `is_causal=False`.
            # The combined mask handles causality.
            attn_output = F.scaled_dot_product_attention(
                query_states,
                key_states,
                value_states,
                # Pass the combined additive mask for both padding and causality
                attn_mask=attention_mask, 
                dropout_p=self.attention_dropout if self.training else 0.0,
                # SDPA will apply an *internal* causal mask if True, which conflicts 
                # with the explicit one in `attn_mask`. Set to False.
                is_causal=False, 
            )
            attn_weights = None # No weights outputted by SDPA
            # --- FIX ENDS HERE ---
        
        else:
            # Standard Attention Fallback
            # 1. Scale Q
            attn_weights = torch.matmul(query_states, key_states.transpose(2, 3)) / math.sqrt(self.head_dim)
            
            # 2. Add Causal/Padding Mask
            # 2. Add Causal/Padding Mask
            if attention_mask is not None:
                # attention_mask is already a 4D additive mask [bsz, 1, q_len, kv_seq_len]
                attn_weights = attn_weights + attention_mask

            if is_causal:
                # In the standard attention path, the causal mask is applied *before* the padding mask
                # by combining them in _prepare_decoder_attention_mask.
                # Since `attention_mask` is the *combined* mask, no extra step is needed here,
                # but we must ensure the `_prepare_decoder_attention_mask` correctly handles the causal aspect
                # even when SDPA is not used, which it does (by creating `combined_attention_mask`).
                pass # The combined mask already handles causality.

            # 3. Softmax
            attn_weights = nn.functional.softmax(attn_weights, dim=-1, dtype=torch.float32).to(query_states.dtype)

            # 4. Dropout
            if self.attention_dropout > 0.0:
                 attn_weights = F.dropout(attn_weights, p=self.attention_dropout, training=self.training)
            
            # 5. Output
            attn_output = torch.matmul(attn_weights, value_states)

        # Reshape output: [bsz, n_heads, q_len, head_dim] -> [bsz, q_len, hidden_dim]
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(bsz, q_len, self.hidden_dim)
        
        # Final linear projection
        attn_output = self.o_proj(attn_output)
        
        if not output_attentions:
            attn_weights = None

        return attn_output, attn_weights, past_key_value_out


class YsnrfdDecoderLayer(nn.Module):
    """
    Single Decoder Layer using Pre-Normalization and Residual connections.
    """
    def __init__(self, config: YsnrfdConfig, layer_idx: Optional[int] = None):
        super().__init__()
        self.config = config
        self.hidden_dim = config.hidden_size
        
        # Self-Attention Block
        self.self_attn = YsnrfdAttention(config=config, layer_idx=layer_idx)
        self.input_layernorm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        
        # Feed-Forward Block
        self.mlp = YsnrfdFeedForward(config)
        self.post_attention_layernorm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        
        # Dropout for residual connections
        self.dropout = nn.Dropout(config.hidden_dropout_prob)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: bool = False,
        use_cache: Optional[bool] = False,
    ) -> Tuple[torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]]:
        
        # Self Attention
        residual = hidden_states
        
        # Pre-Normalization
        attn_input = self.input_layernorm(hidden_states)
        
        attn_output, attn_weights, past_key_value = self.self_attn(
            attn_input,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
        )
        
        # Residual connection 1: Add Dropout(Attention_Output) to input
        hidden_states = residual + self.dropout(attn_output)
        
        # Feed Forward
        residual = hidden_states
        
        # Pre-Normalization
        mlp_input = self.post_attention_layernorm(hidden_states)
        
        mlp_output = self.mlp(mlp_input)
        
        # Residual connection 2: Add Dropout(MLP_Output) to input
        hidden_states = residual + self.dropout(mlp_output)

        return hidden_states, past_key_value, attn_weights


def _make_causal_mask(
    input_ids_shape: torch.Size, dtype: torch.dtype, device: torch.device, past_key_values_length: int = 0
):
    """
    Makes a causal mask (look-ahead mask) of shape [bsz, 1, tgt_len, src_len].
    This mask is additive (using float.min).
    """
    bsz, tgt_len = input_ids_shape
    src_len = tgt_len + past_key_values_length
    
    # Create an upper triangular matrix with 1's above the main diagonal
    # This matrix should be 0 on and below the diagonal, and 1 above it (masking future)
    # torch.triu(..., diagonal=1) produces 1s where column > row, 0 otherwise.
    mask = torch.full((tgt_len, src_len), 
                       torch.finfo(dtype).min, 
                       dtype=dtype, 
                       device=device)
    
    # Fill the lower triangle (including diagonal) with 0.0 (unmasking)
    mask_cond = torch.arange(tgt_len, device=device)[:, None] < torch.arange(src_len, device=device)[None, :]
    mask.masked_fill_(mask_cond, 0.0) # Fill future tokens with 0.0

    # Handle past context if present (Generation mode)
    if past_key_values_length > 0:
        # Prepend a block of 0.0s (unmasked) for the past context
        # New tokens need to attend to ALL past tokens.
        mask = torch.cat([torch.zeros((tgt_len, past_key_values_length), dtype=dtype, device=device), mask], dim=-1)

    # Unsqueeze to [1, 1, tgt_len, src_len] for broadcasting with attention weights
    return mask[None, None, :, :].expand(bsz, 1, tgt_len, src_len)


def _expand_mask(mask: torch.Tensor, dtype: torch.dtype, tgt_len: Optional[int] = None):
    """
    Expands a padding mask from [bsz, src_len] to [bsz, 1, tgt_len, src_len].
    The mask value 0 (padding) is converted to a large negative number (additive attention).
    """
    batch_size, src_len = mask.size()
    tgt_len = tgt_len if tgt_len is not None else src_len
    
    # [bsz, src_len] -> [bsz, 1, 1, src_len]
    expanded_mask = mask[:, None, None, :]
    
    # Invert the mask values: 1s (real tokens) become 0.0, 0s (padding) become -inf
    expanded_mask = expanded_mask.to(dtype)
    expanded_mask = (1.0 - expanded_mask) * torch.finfo(dtype).min
    
    # Expand the mask over the target length dimension
    # [bsz, 1, 1, src_len] -> [bsz, 1, tgt_len, src_len]
    return expanded_mask.expand(batch_size, 1, tgt_len, src_len)


class YsnrfdModel(PreTrainedModel):
    """
    The bare Ysnrfd Model (base transformer block).
    """
    config_class = YsnrfdConfig
    base_model_prefix = "model"
    supports_gradient_checkpointing = True
    
    def __init__(self, config: YsnrfdConfig):
        super().__init__(config)
        self.config = config
        self.padding_idx = config.pad_token_id
        self.vocab_size = config.vocab_size
        # FIX: Initialize the gradient_checkpointing attribute
        self.gradient_checkpointing = config.gradient_checkpointing

        # Embedding Layer
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size, self.padding_idx)
        
        # Decoder Layers
        self.layers = nn.ModuleList(
            [YsnrfdDecoderLayer(config, layer_idx=i) for i in range(config.num_hidden_layers)]
        )
        
        # Final Layer Norm (Post-Normalization)
        self.norm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        
        # Initialize weights and apply final processing
        self.post_init()
        
    def _prepare_decoder_attention_mask(self, attention_mask, input_shape, hidden_states, past_key_values_length):
        """
        Creates the combined 4D additive attention mask (Causal + Padding).
        """
        device = hidden_states.device
        dtype = hidden_states.dtype
        bsz, tgt_len = input_shape
        
        # 1. Create the Causal Mask (look-ahead mask)
        causal_mask = _make_causal_mask(input_ids_shape=(bsz, tgt_len), 
                                        dtype=dtype, 
                                        device=device,
                                        past_key_values_length=past_key_values_length)

        # 2. Add Padding Mask (if present)
        if attention_mask is not None:
            # Expand the 2D padding mask [bsz, src_len] to 4D [bsz, 1, tgt_len, src_len]
            expanded_mask = _expand_mask(attention_mask, dtype, tgt_len=tgt_len)
            
            # Combine Causal Mask and Padding Mask by summing the additive masks
            # Since causal mask already covers the context, we only need to add the padding mask's -inf
            combined_attention_mask = expanded_mask + causal_mask
        else:
            # If no padding mask, the causal mask is the final attention mask
            combined_attention_mask = causal_mask

        return combined_attention_mask
    
    def get_input_embeddings(self):
        return self.embed_tokens

    def set_input_embeddings(self, value):
        self.embed_tokens = value
    
    def _set_gradient_checkpointing(self, module, value=False):
        if isinstance(module, YsnrfdModel):
            module.gradient_checkpointing = value

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple, BaseModelOutputWithPast]:
        
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else self.config.use_cache
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict
        
        # 1. Input Validation and Setup
        if input_ids is None:
            raise ValueError("You have to specify input_ids")

        bsz, seq_length = input_ids.shape
        device = input_ids.device
        
        past_key_values_length = past_key_values[0][0].shape[2] if past_key_values is not None else 0
        
        if position_ids is None:
            # Create position_ids for the current batch of tokens
            # If past_key_values is present, the new tokens start after the past length
            position_ids = torch.arange(
                past_key_values_length, seq_length + past_key_values_length, dtype=torch.long, device=device
            )
            # Expand to match batch size
            position_ids = position_ids.unsqueeze(0).expand(bsz, -1)

        # 2. Embeddings
        hidden_states = self.embed_tokens(input_ids)
        
        # 3. Attention Mask
        attention_mask = self._prepare_decoder_attention_mask(
            attention_mask, 
            input_shape=(bsz, seq_length), 
            hidden_states=hidden_states, 
            past_key_values_length=past_key_values_length
        )
        
        # 4. Forward through Decoder Layers
        all_hidden_states = () if output_hidden_states else None
        all_self_attns = () if output_attentions else None
        next_cache = () if use_cache else None
        
        for idx, decoder_layer in enumerate(self.layers):
            if output_hidden_states:
                all_hidden_states += (hidden_states,)
                
            layer_past = past_key_values[idx] if past_key_values is not None else None
            
            # Gradient Checkpointing
            if self.gradient_checkpointing and self.training:
                # Use standard checkpointing
                layer_outputs = torch.utils.checkpoint.checkpoint(
                    decoder_layer,
                    hidden_states,
                    attention_mask,
                    position_ids,
                    layer_past,
                    output_attentions,
                    use_cache,
                    use_reentrant=False,
                )
            else:
                layer_outputs = decoder_layer(
                    hidden_states,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    past_key_value=layer_past,
                    output_attentions=output_attentions,
                    use_cache=use_cache,
                )
                
            hidden_states = layer_outputs[0]
            
            if use_cache:
                next_cache += (layer_outputs[1],)
            if output_attentions:
                all_self_attns += (layer_outputs[2] if len(layer_outputs) > 2 else None,)
        
        # 5. Final Normalization
        hidden_states = self.norm(hidden_states)

        if output_hidden_states:
            all_hidden_states += (hidden_states,)
            
        next_cache = next_cache if use_cache else None

        if not return_dict:
            return tuple(v for v in [hidden_states, next_cache, all_hidden_states, all_self_attns] if v is not None)
        
        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=next_cache,
            hidden_states=all_hidden_states,
            attentions=all_self_attns,
        )


class YsnrfdForCausalLM(PreTrainedModel, GenerationMixin):
    """
    Ysnrfd Model with a Language Modeling head (for next token prediction).
    """
    config_class = YsnrfdConfig
    
    def __init__(self, config: YsnrfdConfig):
        super().__init__(config)
        self.model = YsnrfdModel(config)
        
        # Language Modeling Head (Linear projection to vocab size)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        
        # Initialize weights and apply final processing
        self.post_init()
        
    def get_input_embeddings(self):
        return self.model.embed_tokens

    def set_input_embeddings(self, value):
        self.model.embed_tokens = value
        
    def get_output_embeddings(self):
        return self.lm_head

    def set_output_embeddings(self, new_embeddings):
        self.lm_head = new_embeddings
        
    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
    ) -> Union[Tuple, CausalLMOutputWithPast]:
        
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict
        
        # 1. Forward through the base model
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,
        )
        
        hidden_states = outputs.last_hidden_state
        
        # 2. Language Modeling Head
        logits = self.lm_head(hidden_states)
        
        # 3. Loss Calculation
        loss = None
        if labels is not None:
            # Shift so that tokens < n predict n (next token prediction)
            # Remove the last token from logits (it predicts nothing)
            shift_logits = logits[..., :-1, :].contiguous()
            # Remove the first token from labels (it is predicted by nothing)
            shift_labels = labels[..., 1:].contiguous()
            
            # ⚠️ IMPROVEMENT: Robust check for empty tensors before calculating Loss
            if shift_labels.numel() > 0:
                # CrossEntropyLoss expects (N, C) for logits and (N) for labels
                loss_fct = nn.CrossEntropyLoss(ignore_index=-100)
                loss = loss_fct(shift_logits.view(-1, self.config.vocab_size), shift_labels.view(-1))
            else:
                # If there are no tokens to calculate loss on (e.g., sequence length is 1)
                # This ensures the model does not crash and returns a zero loss.
                loss = torch.tensor(0.0, device=logits.device, requires_grad=True)

        if not return_dict:
            output = (logits,) + outputs[1:]
            return (loss,) + output if loss is not None else output
        
        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )

    def prepare_inputs_for_generation(
        self, input_ids, past_key_values=None, attention_mask=None, inputs_embeds=None, **kwargs
    ):
        # ⚠️ FIX 3: Correct Position ID calculation for generation
        
        # 1. Handle Past Key/Values
        if past_key_values is not None:
            # Incremental decoding: Only the last token needs to be passed in input_ids
            input_ids = input_ids[:, -1].unsqueeze(-1)
            # The length of past keys/values
            past_length = past_key_values[0][0].shape[2]
            
            # The new token's position ID is the length of the past sequence
            position_ids = torch.tensor(
                [past_length], dtype=torch.long, device=input_ids.device
            ).unsqueeze(0).expand(input_ids.shape[0], 1)
        else:
            # First pass (prefill): Position IDs are sequential [0, 1, 2, ..., seq_len-1]
            position_ids = kwargs.get("position_ids", None)
            if position_ids is None:
                # Default calculation for first pass
                position_ids = torch.arange(
                    0, input_ids.shape[-1], dtype=torch.long, device=input_ids.device
                ).unsqueeze(0)
            
        # 2. Update Attention Mask
        if attention_mask is not None and past_key_values is not None:
            # During incremental generation, we append a '1' (unmasked token) to the end of the attention mask
            # The new token is always unmasked in the full sequence.
            attention_mask = torch.cat([attention_mask, attention_mask.new_ones((attention_mask.shape[0], 1))], dim=-1)

        model_inputs = {
            "input_ids": input_ids,
            "position_ids": position_ids,
            "past_key_values": past_key_values,
            "use_cache": kwargs.get("use_cache", True), # Assume use_cache=True for generation
            "attention_mask": attention_mask,
            "output_attentions": kwargs.get("output_attentions", False),
            "output_hidden_states": kwargs.get("output_hidden_states", False),
        }
        return model_inputs
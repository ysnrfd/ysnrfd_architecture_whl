# ysnrfd/utils.py
import torch
import struct
import numpy as np
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple
from transformers import AutoTokenizer, AutoConfig, PreTrainedTokenizer, PreTrainedModel, AutoModelForCausalLM
from tqdm.auto import tqdm
import json
import re
import os

# --- GGUF Constants ---

# GGUF جادویی
GGUF_MAGIC = 0x46554747  # "GGUF"

# انواع تنسور GGML
GGML_TYPE_F32 = 0
GGML_TYPE_F16 = 1
GGML_TYPE_Q4_0 = 2
GGML_TYPE_Q4_1 = 3
GGML_TYPE_Q5_0 = 6
GGML_TYPE_Q5_1 = 7
GGML_TYPE_Q8_0 = 8

# انواع مقادیر متادیتا GGUF
GGUF_VALUE_TYPE_UINT8   = 0
GGUF_VALUE_TYPE_INT8    = 1
GGUF_VALUE_TYPE_UINT16  = 2
GGUF_VALUE_TYPE_INT16   = 3
GGUF_VALUE_TYPE_UINT32  = 4
GGUF_VALUE_TYPE_INT32   = 5
GGUF_VALUE_TYPE_FLOAT32 = 6
GGUF_VALUE_TYPE_BOOL    = 7
GGUF_VALUE_TYPE_STRING  = 8
GGUF_VALUE_TYPE_ARRAY   = 9
GGUF_VALUE_TYPE_UINT64  = 10
GGUF_VALUE_TYPE_INT64   = 11
GGUF_VALUE_TYPE_FLOAT64 = 12

class GGUFWriter:
    """
    کلاسی برای نوشتن فایل‌های GGUF به صورت صحیح و تراز شده.
    
    این کلاس اکنون از انواع آرایه برای واژگان و ترازبندی تنسور
    پشتیبانی می‌کند که برای GGUF v3 ضروری است.
    """
    DEFAULT_ALIGNMENT = 32

    def __init__(self, output_path: str, arch: str = "ysnrfd", alignment: int = DEFAULT_ALIGNMENT):
        self.output_path = output_path
        self.arch = arch
        self.kv_data = {}
        self.tensor_data_list = []  # متادیتا و تنسور (در RAM) را ذخیره می‌کند
        self.tensor_names = set()
        self.f = open(output_path, "wb")
        self.alignment = alignment
        
        # --- نوشتن هدر GGUF ---
        # 1. شماره جادویی
        self._write_u32(GGUF_MAGIC)
        # 2. نسخه GGUF (از v3 استفاده می‌کنیم)
        self._write_u32(3)
        
        # 3. مکان‌هایی برای تعداد تنسور و متادیتا (بعداً به‌روز می‌شوند)
        self.tensor_count_pos = self.f.tell()
        self._write_u64(0)  # tensor_count (موقت)
        self.metadata_count_pos = self.f.tell()
        self._write_u64(0)  # metadata_kv_count (موقت)

        # اضافه کردن متادیتای ضروری
        self.add_kv("general.architecture", arch)
        self.add_kv("general.alignment", alignment)

    # --- توابع کمکی نوشتن باینری ---
    
    def _write_u8(self, value: int):
        self.f.write(struct.pack("<B", value))

    def _write_u32(self, value: int):
        self.f.write(struct.pack("<I", value))

    def _write_u64(self, value: int):
        self.f.write(struct.pack("<Q", value))

    def _write_float32(self, value: float):
        self.f.write(struct.pack("<f", value))

    def _write_string(self, value: str):
        """یک رشته با انکدینگ UTF-8 می‌نویسد."""
        value_bytes = value.encode("utf-8")
        self._write_u64(len(value_bytes))
        self.f.write(value_bytes)
    
    def _write_string_latin1(self, value: str):
        """
        یک رشته با انکدینگ 'latin-1' می‌نویسد.
        این برای هک واژگان GGUF استفاده می‌شود که بایت‌ها به عنوان latin-1 ذخیره می‌شوند.
        """
        value_bytes = value.encode("latin-1")
        self._write_u64(len(value_bytes))
        self.f.write(value_bytes)

    # --- توابع مدیریت متادیتا و تنسور ---

    def add_kv(self, key: str, value: Any):
        """یک جفت کلید-مقدار به متادیتا اضافه می‌کند."""
        if key in self.kv_data:
            print(f"هشدار: بازنویسی کلید متادیتا {key}")
        self.kv_data[key] = value

    def add_tensor(self, name: str, tensor: torch.Tensor, dtype_str: str = "f16"):
        """یک تنسور را برای نوشتن اضافه می‌کند (هنوز نمی‌نویسد)."""
        if name in self.tensor_names:
            raise ValueError(f"تنسور {name} از قبل وجود دارد")
        
        self.tensor_names.add(name)
        
        # تبدیل تنسور به نوع داده مورد نظر
        if dtype_str == "f16":
            tensor = tensor.half()
        elif dtype_str == "f32":
            tensor = tensor.float()
        else:
            raise ValueError(f"نوع داده پشتیبانی نشده: {dtype_str}")
        
        # تنسور را (در RAM) نگه می‌دارد تا بعداً نوشته شود
        self.tensor_data_list.append((name, tensor))

    def _write_metadata_value(self, value: Any):
        """مقدار متادیتا را با نوع صحیح GGUF می‌نویسد."""
        if isinstance(value, str):
            self._write_u32(GGUF_VALUE_TYPE_STRING)
            self._write_string(value)
        elif isinstance(value, bool):
            self._write_u32(GGUF_VALUE_TYPE_BOOL)
            self._write_u8(1 if value else 0)
        elif isinstance(value, int):
            # از u64 به عنوان پیش‌فرض برای سادگی استفاده می‌کنیم
            self._write_u32(GGUF_VALUE_TYPE_UINT64)
            self._write_u64(value)
        elif isinstance(value, float):
            # پیش‌فرض f32
            self._write_u32(GGUF_VALUE_TYPE_FLOAT32)
            self._write_float32(value)
        elif isinstance(value, list):
            if not value:
                # مدیریت لیست خالی
                self._write_u32(GGUF_VALUE_TYPE_ARRAY)
                self._write_u32(GGUF_VALUE_TYPE_STRING) # نوع آیتم ساختگی (مهم نیست)
                self._write_u64(0) # تعداد صفر
                return

            # تشخیص نوع آیتم آرایه
            item_type = type(value[0])
            self._write_u32(GGUF_VALUE_TYPE_ARRAY)

            if item_type is str:
                # مورد خاص: توکن‌ها به عنوان 'latin-1' نوشته می‌شوند
                self._write_u32(GGUF_VALUE_TYPE_STRING)
                self._write_u64(len(value))
                for item in value:
                    self._write_string_latin1(item)
            elif item_type is float:
                self._write_u32(GGUF_VALUE_TYPE_FLOAT32)
                self._write_u64(len(value))
                for item in value:
                    self._write_float32(item)
            elif item_type is int:
                 self._write_u32(GGUF_VALUE_TYPE_UINT64)
                 self._write_u64(len(value))
                 for item in value:
                    self._write_u64(item)
            else:
                raise ValueError(f"نوع آیتم آرایه پشتیبانی نشده: {item_type}")
        else:
            raise ValueError(f"نوع متادیتا پشتیبانی نشده: {type(value)}")

    def _write_metadata(self):
        """تمام جفت‌های کلید-مقدار متادیتا را می‌نویسد."""
        for key, value in self.kv_data.items():
            self._write_string(key)
            self._write_metadata_value(value)

    def finalize(self):
        """
        فایل GGUF را نهایی می‌کند.
        ساختار GGUF:
        1. هدر (در __init__ نوشته شد)
        2. متادیتا Key-Value
        3. اطلاعات تنسور (نام، ابعاد، نوع، آفست)
        4. پدینگ (Padding) برای تراز کردن شروع داده
        5. داده‌های تنسور (بلوک‌های باینری تراز شده)
        """
        try:
            # --- 2. نوشتن متادیتا Key-Value ---
            self._write_metadata()
            
            # --- 3. نوشتن اطلاعات تنسور ---
            tensor_info_offset = self.f.tell()
            tensor_data_blobs = []
            tensor_data_offsets_list = []

            # محاسبه اندازه بخش اطلاعات تنسور برای یافتن آفست شروع داده
            tensor_info_size = 0
            for name, tensor in self.tensor_data_list:
                tensor_info_size += 8 + len(name.encode('utf-8')) # name (len + data)
                tensor_info_size += 4 # n_dims
                tensor_info_size += 8 * len(tensor.shape) # dims
                tensor_info_size += 4 # type
                tensor_info_size += 8 # offset
            
            # آفست شروع داده‌ها باید تراز شود
            data_start_pos = tensor_info_offset + tensor_info_size
            padding = (self.alignment - (data_start_pos % self.alignment)) % self.alignment
            data_start_pos += padding
            
            current_data_offset = data_start_pos

            # اکنون بخش اطلاعات تنسور را بنویسید
            for name, tensor in self.tensor_data_list:
                # نوشتن نام تنسور
                self._write_string(name)
                
                # نوشتن شکل (ابعاد) تنسور (به ترتیب معکوس)
                shape = tensor.shape
                self._write_u32(len(shape)) # n_dims
                for dim in reversed(shape):
                    self._write_u64(dim)
                
                # تشخیص و نوشتن نوع تنسور
                if tensor.dtype == torch.float16:
                    tensor_type = GGML_TYPE_F16
                elif tensor.dtype == torch.float32:
                    tensor_type = GGML_TYPE_F32
                else:
                    raise ValueError(f"نوع داده تنسور پشتیبانی نشده: {tensor.dtype}")
                
                self._write_u32(tensor_type)
                
                # محاسبه و نوشتن آفست داده تراز شده
                padding = (self.alignment - (current_data_offset % self.alignment)) % self.alignment
                current_data_offset += padding
                
                self._write_u64(current_data_offset)
                tensor_data_offsets_list.append(current_data_offset)
                
                # آماده‌سازی داده باینری (blob) و به‌روزرسانی آفست
                blob = tensor.cpu().numpy()
                tensor_data_blobs.append(blob)
                current_data_offset += blob.nbytes
            
            # --- 4. نوشتن پدینگ ---
            # پدینگ بین انتهای بخش اطلاعات تنسور و شروع بخش داده
            current_pos = self.f.tell()
            padding_to_data = data_start_pos - current_pos
            if padding_to_data < 0:
                raise Exception("محاسبه اندازه اطلاعات تنسور اشتباه بود (پدینگ منفی)")
            self.f.write(b"\x00" * padding_to_data)
            
            # --- 5. نوشتن داده‌های تنسور ---
            if self.f.tell() != data_start_pos:
                 raise Exception(f"اشاره‌گر فایل {self.f.tell()} با شروع داده محاسبه شده {data_start_pos} مطابقت ندارد")

            for blob, offset in zip(tensor_data_blobs, tensor_data_offsets_list):
                # نوشتن پدینگ ترازکننده برای این تنسور
                padding = offset - self.f.tell()
                if padding < 0:
                    raise Exception("محاسبه آفست داده تنسور اشتباه بود (پدینگ منفی)")
                self.f.write(b"\x00" * padding)
                
                if self.f.tell() != offset:
                    raise Exception(f"اشاره‌گر فایل {self.f.tell()} با آفست تنسور محاسبه شده {offset} مطابقت ندارد")

                # نوشتن داده باینری تنسور
                blob.tofile(self.f)
            
            # --- به‌روزرسانی هدر ---
            # بازگشت به هدر برای نوشتن تعداد صحیح
            self.f.seek(self.tensor_count_pos)
            self._write_u64(len(self.tensor_data_list))
            
            self.f.seek(self.metadata_count_pos)
            self._write_u64(len(self.kv_data))
            
        finally:
            # بستن فایل
            self.f.close()

def _get_vocab_token_str_for_gguf(token: str) -> str:
    """
    توکن رشته‌ای را به رشته 'latin-1' مورد نیاز GGUF تبدیل می‌کند.
    توکن‌های بایت خاص مانند <0xXX> را مدیریت می‌کند.
    """
    match = re.match(r"<0x([0-9A-Fa-f]{2})>", token)
    if match:
        # اگر توکن بایت <0xXX> بود
        token_bytes = bytes([int(match.group(1), 16)])
    else:
        # در غیر این صورت، رشته را به عنوان utf-8 انکود کن
        token_bytes = token.encode("utf-8")
    
    # هک GGUF: بایت‌ها را به عنوان رشته latin-1 ذخیره می‌کند
    return token_bytes.decode("latin-1")

def convert_to_gguf(
    model_path: str,
    output_path: str,
    tokenizer_path: Optional[str] = None,
    dtype: str = "f16"
):
    """
    یک مدل Hugging Face Ysnrfd را به فرمت GGUF تبدیل می‌کند.
    
    Args:
        model_path (`str`): مسیر دایرکتوری مدل Hugging Face.
        output_path (`str`): مسیر فایل GGUF خروجی.
        tokenizer_path (`str`, *optional*): مسیر توکنایزر. اگر None باشد، از model_path استفاده می‌شود.
        dtype (`str`, *optional*): نوع داده وزن‌ها ('f16' یا 'f32').
    """
    print(f"در حال تبدیل مدل از {model_path} به {output_path} با نوع داده {dtype}")
    
    # بارگیری کانفیگ مدل
    # trust_remote_code=True
    config = AutoConfig.from_pretrained(model_path, trust_remote_code=True)
    
    # مقداردهی اولیه GGUFWriter
    # تراز پیش‌فرض (32) را استفاده می‌کنیم
    writer = GGUFWriter(output_path, arch="ysnrfd")
    
    # --- افزودن متادیتای مدل ---
    # (مقادیر 'general.architecture' و 'general.alignment' قبلاً در __init__ اضافه شدند)
    writer.add_kv("general.name", "Ysnrfd")
    writer.add_kv("general.description", "Ysnrfd language model")
    
    # پارامترهای مدل
    writer.add_kv("ysnrfd.block_count", config.num_hidden_layers)
    writer.add_kv("ysnrfd.embedding_length", config.hidden_size)
    writer.add_kv("ysnrfd.feed_forward_length", config.intermediate_size)
    writer.add_kv("ysnrfd.attention.head_count", config.num_attention_heads)
    
    # بررسی GQA/MQA
    if hasattr(config, "num_key_value_heads"):
        writer.add_kv("ysnrfd.attention.head_count_kv", config.num_key_value_heads)
    else:
        writer.add_kv("ysnrfd.attention.head_count_kv", config.num_attention_heads)
        
    writer.add_kv("ysnrfd.rope.dimension_count", config.hidden_size // config.num_attention_heads)
    
    if hasattr(config, "rope_theta"):
        writer.add_kv("ysnrfd.rope.freq_base", config.rope_theta)
    
    # این فقط یک حدس است، اگر مدل از HF باشد، این معمولاً درست است
    writer.add_kv("ysnrfd.tensor_data_layout", "LLAMA_HF")
    
    # --- پردازش توکنایزر ---
    tokenizer = None
    try:
        tokenizer_path = tokenizer_path or model_path
        if not os.path.exists(tokenizer_path):
            raise FileNotFoundError("مسیر توکنایزر یافت نشد")
            
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, trust_remote_code=True)
        
        # دریافت واژگان
        vocab = tokenizer.get_vocab() # {token_str: token_id}
        
        # GGUFv3 به لیست‌هایی مرتب شده بر اساس ID نیاز دارد
        tokens_list = [""] * len(vocab)
        scores_list = [0.0] * len(vocab)
        
        for token_str, token_id in vocab.items():
            if token_id >= len(tokens_list):
                # اگر ID ها پیوسته نباشند، لیست‌ها را گسترش می‌دهیم
                tokens_list.extend([""] * (token_id - len(tokens_list) + 1))
                scores_list.extend([0.0] * (token_id - len(scores_list) + 1))
                
            tokens_list[token_id] = _get_vocab_token_str_for_gguf(token_str)
            # score ها معمولاً در توکنایزرهای HF در دسترس نیستند
            scores_list[token_id] = 0.0 

        # افزودن لیست‌های واژگان به متادیتا
        writer.add_kv("tokenizer.ggml.tokens", tokens_list)
        writer.add_kv("tokenizer.ggml.scores", scores_list)

        # تشخیص نوع مدل توکنایزر
        try:
            config_path = os.path.join(tokenizer_path, "tokenizer_config.json")
            if os.path.exists(config_path):
                with open(config_path, "r", encoding="utf-8") as f:
                    tokenizer_config = json.load(f)
                tokenizer_class = tokenizer_config.get("tokenizer_class", "")
                
                if "LlamaTokenizer" in tokenizer_class:
                    writer.add_kv("tokenizer.ggml.model", "llama")
                elif "GPT2Tokenizer" in tokenizer_class:
                    writer.add_kv("tokenizer.ggml.model", "gpt2")
                else:
                    writer.add_kv("tokenizer.ggml.model", "unknown")
            # اگر sentencepiece model وجود داشته باشد، احتمالاً llama است
            elif os.path.exists(os.path.join(tokenizer_path, "tokenizer.model")):
                 writer.add_kv("tokenizer.ggml.model", "llama")
            else:
                 writer.add_kv("tokenizer.ggml.model", "unknown")
        except Exception as e:
             print(f"هشدار: نتوانست نوع توکنایزر را تشخیص دهد: {e}")
             writer.add_kv("tokenizer.ggml.model", "unknown")
        
        # افزودن merges برای توکنایزرهای BPE (مانند GPT2)
        if writer.kv_data.get("tokenizer.ggml.model") == "gpt2":
            merges_path = os.path.join(tokenizer_path, "merges.txt")
            if os.path.exists(merges_path):
                merges = []
                with open(merges_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        merges.append(line)
                writer.add_kv("tokenizer.ggml.merges", merges)

        # افزودن توکن‌های ویژه
        if hasattr(tokenizer, "bos_token_id") and tokenizer.bos_token_id is not None:
            writer.add_kv("tokenizer.ggml.bos_token_id", tokenizer.bos_token_id)
        if hasattr(tokenizer, "eos_token_id") and tokenizer.eos_token_id is not None:
            writer.add_kv("tokenizer.ggml.eos_token_id", tokenizer.eos_token_id)
        if hasattr(tokenizer, "pad_token_id") and tokenizer.pad_token_id is not None:
            writer.add_kv("tokenizer.ggml.padding_token_id", tokenizer.pad_token_id)
        if hasattr(tokenizer, "unk_token_id") and tokenizer.unk_token_id is not None:
            writer.add_kv("tokenizer.ggml.unknown_token_id", tokenizer.unk_token_id)
                
    except Exception as e:
        print(f"هشدار: پردازش توکنایزر با خطا مواجه شد: {e}")
        print("فایل GGUF بدون اطلاعات توکنایزر ایجاد خواهد شد.")

    # --- پردازش تنسورها ---
    
    # بارگیری مدل (فقط state dict مورد نیاز است)
    print("در حال بارگیری state dict مدل...")
    # از AutoModel استفاده می‌کنیم تا مطمئن شویم معماری ثبت شده است
    # trust_remote_code=True
    model = AutoModelForCausalLM.from_pretrained(model_path, trust_remote_code=True)
    state_dict = model.state_dict()
    
    print("در حال پردازش تنسورها...")
    for name, tensor in tqdm(state_dict.items(), desc="تبدیل تنسورها"):
        # تبدیل نام تنسور از HF به GGUF
        gguf_name = name
        gguf_name = gguf_name.replace("model.", "")
        gguf_name = gguf_name.replace("embed_tokens.weight", "token_embd.weight")
        gguf_name = gguf_name.replace("norm.weight", "output_norm.weight")
        gguf_name = gguf_name.replace("lm_head.weight", "output.weight")
        
        # نام‌گذاری لایه‌ها
        gguf_name = re.sub(r"layers\.(\d+)\.self_attn\.q_proj\.weight", r"blk.\1.attn_q.weight", gguf_name)
        gguf_name = re.sub(r"layers\.(\d+)\.self_attn\.k_proj\.weight", r"blk.\1.attn_k.weight", gguf_name)
        gguf_name = re.sub(r"layers\.(\d+)\.self_attn\.v_proj\.weight", r"blk.\1.attn_v.weight", gguf_name)
        gguf_name = re.sub(r"layers\.(\d+)\.self_attn\.o_proj\.weight", r"blk.\1.attn_output.weight", gguf_name)
        
        gguf_name = re.sub(r"layers\.(\d+)\.mlp\.gate_proj\.weight", r"blk.\1.ffn_gate.weight", gguf_name) # LLaMA v2
        gguf_name = re.sub(r"layers\.(\d+)\.mlp\.down_proj\.weight", r"blk.\1.ffn_down.weight", gguf_name)
        gguf_name = re.sub(r"layers\.(\d+)\.mlp\.up_proj\.weight", r"blk.\1.ffn_up.weight", gguf_name)
        
        # نام‌های جایگزین MLP (اگر مدل از w1, w2, w3 استفاده می‌کند)
        gguf_name = re.sub(r"layers\.(\d+)\.mlp\.w1\.weight", r"blk.\1.ffn_gate.weight", gguf_name)
        gguf_name = re.sub(r"layers\.(\d+)\.mlp\.w2\.weight", r"blk.\1.ffn_down.weight", gguf_name)
        gguf_name = re.sub(r"layers\.(\d+)\.mlp\.w3\.weight", r"blk.\1.ffn_up.weight", gguf_name)
        
        # LayerNorms
        gguf_name = re.sub(r"layers\.(\d+)\.input_layernorm\.weight", r"blk.\1.attn_norm.weight", gguf_name)
        gguf_name = re.sub(r"layers\.(\d+)\.post_attention_layernorm\.weight", r"blk.\1.ffn_norm.weight", gguf_name)
        
        # افزودن تنسور به GGUFWriter
        writer.add_tensor(gguf_name, tensor, dtype_str=dtype)
    
    # آزاد کردن حافظه مدل
    del model
    del state_dict
    
    # نهایی کردن فایل GGUF
    print("در حال نهایی کردن فایل GGUF...")
    writer.finalize()
    
    print(f"تبدیل با موفقیت انجام شد! فایل GGUF در {output_path} ذخیره شد.")

def convert_hf_to_gguf(model_path: str, output_path: str, tokenizer_path: Optional[str] = None, dtype: str = "f16"):
    """
    یک تابع پوششی (wrapper) برای فراخوانی convert_to_gguf.
    
    Args:
        model_path (`str`): مسیر دایرکتوری مدل Hugging Face.
        output_path (`str`): مسیر فایل GGUF خروجی.
        tokenizer_path (`str`, *optional*): مسیر توکنایزر. اگر None باشد، از model_path استفاده می‌شود.
        dtype (`str`, *optional*): نوع داده وزن‌ها ('f16' یا 'f32').
    """
    convert_to_gguf(model_path, output_path, tokenizer_path, dtype)

# --- مثال برای اجرا (در صورت نیاز) ---
if __name__ == "__main__":
    # برای تست، این بخش را از کامنت خارج کنید و مسیرها را تنظیم کنید
    # print("شروع اسکریپت تبدیل...")
    # 
    # # مسیر مدل Hugging Face خود را اینجا قرار دهید
    # HUGGING_FACE_MODEL_PATH = "./my_hf_model" 
    # # مسیر فایل GGUF خروجی
    # OUTPUT_GGUF_PATH = "./my_model.gguf"
    # 
    # if os.path.exists(HUGGING_FACE_MODEL_PATH):
    #     try:
    #         convert_hf_to_gguf(
    #             model_path=HUGGING_FACE_MODEL_PATH,
    #             output_path=OUTPUT_GGUF_PATH,
    #             dtype="f16"  # یا "f32"
    #         )
    #     except Exception as e:
    #         print(f"\nخطا در هنگام تبدیل: {e}")
    #         import traceback
    #         traceback.print_exc()
    # else:
    #     print(f"مسیر مدل {HUGGING_FACE_MODEL_PATH} یافت نشد.")
    #     print("لطفاً متغیر HUGGING_FACE_MODEL_PATH را در انتهای utils.py تنظیم کنید.")
    pass
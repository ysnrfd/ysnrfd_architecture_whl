# ysnrfd/configuration.py
from transformers import PretrainedConfig
from typing import Dict, Any, Optional

class YsnrfdConfig(PretrainedConfig):
    """
    Configuration class for Ysnrfd model.
    This class holds all configuration parameters for the Ysnrfd model architecture,
    compatible with the Hugging Face ecosystem.
    
    Args:
        vocab_size (`int`, *optional*, defaults to 50257):
            Vocabulary size of the Ysnrfd model (matches GPT-2 tokenizer).
        hidden_size (`int`, *optional*, defaults to 768):
            Dimensionality of the hidden layers.
        intermediate_size (`int`, *optional*, defaults to 3072):
            Dimensionality of the "intermediate" (i.e., feed-forward) layer.
        num_hidden_layers (`int`, *optional*, defaults to 12):
            Number of hidden layers in the Transformer decoder.
        num_attention_heads (`int`, *optional*, defaults to 12):
            Number of attention heads for each attention layer.
        max_position_embeddings (`int`, *optional*, defaults to 2048):
            The maximum sequence length that this model might ever be used with.
        initializer_range (`float`, *optional*, defaults to 0.02):
            The standard deviation of the truncated_normal_initializer for initializing all weight matrices.
        rms_norm_eps (`float`, *optional*, defaults to 1e-6):
            The epsilon used by the rms normalization layers.
        rope_theta (`float`, *optional*, defaults to 10000.0):
            The base period of the RoPE embeddings.
        use_cache (`bool`, *optional*, defaults to `True`):
            Whether or not the model should return the last key/values attentions (not used by all models).
        use_flash_attn (`bool`, *optional*, defaults to `False`):
            Whether to use Flash Attention 2 if available.
        gradient_checkpointing (`bool`, *optional*, defaults to `False`):
            Whether to use gradient checkpointing to save memory at the expense of slower backward pass.
        tie_word_embeddings (`bool`, *optional*, defaults to `True`):
            Whether to tie the weights of the input embeddings and the output embeddings.
        bos_token_id (`int`, *optional*, defaults to 50256):
            The id of the beginning of sentence token.
        eos_token_id (`int`, *optional*, defaults to 50256):
            The id of the end of sentence token.
        pad_token_id (`int`, *optional*, defaults to 50256):
            The id of the padding token.
        use_gradient_accumulation (`bool`, *optional*, defaults to `True`):
            Whether to use gradient accumulation for training.
        gradient_accumulation_steps (`int`, *optional*, defaults to 4):
            Number of steps to accumulate gradients before updating weights.
        early_stopping_patience (`int`, *optional*, defaults to 3):
            Number of evaluation steps with no improvement to wait before stopping training.
    """
    model_type = "ysnrfd"
    is_composition = False
    
    def __init__(
        self,
        vocab_size: int = 50257,
        hidden_size: int = 768,
        intermediate_size: int = 3072,
        num_hidden_layers: int = 12,
        num_attention_heads: int = 12,
        max_position_embeddings: int = 2048,
        initializer_range: float = 0.02,
        rms_norm_eps: float = 1e-6,
        rope_theta: float = 10000.0,
        attention_dropout: float = 0.0,
        hidden_dropout_prob: float = 0.0,
        use_cache: bool = True,
        use_flash_attn: bool = False,
        gradient_checkpointing: bool = False,
        tie_word_embeddings: bool = True,
        attention_bias: bool = False,
        bos_token_id: int = 50256,
        eos_token_id: int = 50256,
        pad_token_id: int = 50256,
        use_gradient_accumulation: bool = True,
        gradient_accumulation_steps: int = 4,
        early_stopping_patience: int = 3,
        **kwargs
    ):
        # Validate hidden_size is divisible by num_attention_heads
        if hidden_size % num_attention_heads != 0:
            raise ValueError(
                f"hidden_size ({hidden_size}) must be a multiple of num_attention_heads ({num_attention_heads})"
            )
        
        # FIX: Removed redundant assignment to kwargs.
        # These values are passed directly to super().__init__ anyway.
            
        super().__init__(
            vocab_size=vocab_size,
            hidden_size=hidden_size,
            intermediate_size=intermediate_size,
            num_hidden_layers=num_hidden_layers,
            num_attention_heads=num_attention_heads,
            max_position_embeddings=max_position_embeddings,
            initializer_range=initializer_range,
            rms_norm_eps=rms_norm_eps,
            rope_theta=rope_theta,
            attention_dropout=attention_dropout,
            hidden_dropout_prob=hidden_dropout_prob,
            use_cache=use_cache,
            use_flash_attn=use_flash_attn,
            gradient_checkpointing=gradient_checkpointing,
            tie_word_embeddings=tie_word_embeddings,
            attention_bias=attention_bias,
            bos_token_id=bos_token_id,
            eos_token_id=eos_token_id,
            pad_token_id=pad_token_id,
            use_gradient_accumulation=use_gradient_accumulation,
            gradient_accumulation_steps=gradient_accumulation_steps,
            early_stopping_patience=early_stopping_patience,
            **kwargs
        )
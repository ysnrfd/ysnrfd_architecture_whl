# ysnrfd/evaluation.py
import torch
from torch.utils.data import DataLoader
from tqdm.auto import tqdm
import logging
from transformers import PreTrainedTokenizer
from .modeling import YsnrfdForCausalLM
import numpy as np
from typing import Tuple, List, Dict, Optional
logger = logging.getLogger(__name__)

class Evaluator:
    """
    A comprehensive class to evaluate a trained Ysnrfd model.
    
    Args:
        model (`YsnrfdForCausalLM`): The trained model.
        tokenizer (`PreTrainedTokenizer`, *optional*): The tokenizer corresponding to the model.
        device (`torch.device`): The device to perform evaluation on.
        compute_accuracy (`bool`, *optional*, defaults to `True`): Whether to compute accuracy.
    """
    def __init__(
        self, 
        model: YsnrfdForCausalLM, 
        tokenizer: PreTrainedTokenizer = None, 
        device: torch.device = None,
        compute_accuracy: bool = True
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device if device else torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = self.model.to(self.device)
        self.compute_accuracy = compute_accuracy
    
    def calculate_perplexity(self, dataloader: DataLoader) -> Tuple[float, float, Optional[float]]:
        """
        Calculates the perplexity, average loss, and optionally accuracy of the model.
        
        Args:
            dataloader (`DataLoader`): The data loader for the evaluation set.
            
        Returns:
            `Tuple[float, float, Optional[float]]`: 
            The average loss, perplexity, and accuracy (or None if not computed).
        """
        self.model.eval()
        total_loss = 0.0
        total_tokens = 0
        total_correct = 0
        total_predictions = 0
        accuracy = None
        
        with torch.no_grad():
            for batch in tqdm(dataloader, desc="Evaluating", leave=False):
                # Move batch to device
                batch = {k: v.to(self.device) for k, v in batch.items()}
                
                # Forward pass
                outputs = self.model(**batch)
                # loss = outputs.loss # This is the average loss for the batch
                
                # For perplexity calculation, we need to sum the loss over tokens
                # Get logits and labels
                shift_logits = outputs.logits[..., :-1, :].contiguous()
                shift_labels = batch['input_ids'][..., 1:].contiguous()
                
                # Create loss mask (ignore padding tokens)
                pad_token_id = self.model.config.pad_token_id if self.model.config.pad_token_id is not None else -100
                loss_mask = (shift_labels != pad_token_id).float()
                
                # Calculate loss per token
                loss_fct = torch.nn.CrossEntropyLoss(reduction='none')
                token_loss = loss_fct(
                    shift_logits.view(-1, shift_logits.size(-1)), 
                    shift_labels.view(-1)
                )
                
                # Apply loss mask
                token_loss = token_loss.view(shift_labels.shape) * loss_mask
                
                # Sum valid losses and count valid tokens
                total_loss += token_loss.sum().item()
                total_tokens += loss_mask.sum().item()
                
                # Calculate accuracy if requested
                if self.compute_accuracy and self.tokenizer:
                    predictions = torch.argmax(shift_logits, dim=-1)
                    correct = ((predictions == shift_labels) & (loss_mask.bool())).sum().item()
                    total_correct += correct
                    total_predictions += loss_mask.sum().item()
        
        # Handle division by zero
        if total_tokens == 0:
            logger.warning("No valid tokens found during evaluation. Returning inf.")
            return float('inf'), float('inf'), None
            
        # Calculate average loss and perplexity
        avg_loss = total_loss / total_tokens
        perplexity = np.exp(avg_loss)
        
        # Log results
        logger.info(f"Average Loss: {avg_loss:.4f}")
        logger.info(f"Perplexity: {perplexity:.2f}")
        
        # FIX: Calculate accuracy and log it, then return all three values
        if self.compute_accuracy and self.tokenizer:
            if total_predictions > 0:
                accuracy = total_correct / total_predictions
                logger.info(f"Accuracy: {accuracy:.4f} ({total_correct}/{total_predictions})")
            else:
                logger.warning("Accuracy computed, but no valid predictions were found.")
                accuracy = 0.0 # Or None, 0.0 is probably better
        
        return avg_loss, perplexity, accuracy
    
    def generate_samples(self, prompts: List[str], max_length: int = 100, num_samples: int = 3) -> List[str]:
        """
        Generates text samples from the model.
        
        Args:
            prompts (`List[str]`): List of prompt strings.
            max_length (`int`, *optional*, defaults to 100): Maximum length of generated text.
            num_samples (`int`, *optional*, defaults to 3): Number of samples to generate per prompt.
            
        Returns:
            `List[str]`: Generated text samples.
        """
        if not self.tokenizer:
            raise ValueError("Tokenizer is required for text generation")
        
        self.model.eval()
        generated_texts = []
        
        with torch.no_grad():
            for prompt in prompts:
                inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512).to(self.device)
                
                for _ in range(num_samples):
                    outputs = self.model.generate(
                        **inputs,
                        max_length=max_length + inputs["input_ids"].shape[1],
                        do_sample=True,
                        top_p=0.95,
                        top_k=50,
                        temperature=0.7,
                        pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id
                    )
                    
                    generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
                    generated_texts.append(generated_text)
        
        return generated_texts
    
    def calculate_metrics(self, dataloader: DataLoader) -> Dict[str, float]:
        """
        Calculates multiple evaluation metrics.
        
        Args:
            dataloader (`DataLoader`): The data loader for the evaluation set.
            
        Returns:
            `Dict[str, float]`: Dictionary of evaluation metrics.
        """
        metrics = {}
        
        # FIX: Unpack all three return values from calculate_perplexity
        avg_loss, perplexity, accuracy = self.calculate_perplexity(dataloader)
        
        metrics["loss"] = avg_loss
        metrics["perplexity"] = perplexity
        
        # FIX: Check if accuracy is not None before adding it
        if accuracy is not None:
            metrics["accuracy"] = accuracy
        elif self.compute_accuracy and not self.tokenizer:
             logger.warning("Could not calculate accuracy because tokenizer was not provided.")
        
        return metrics
# ysnrfd/training.py
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
# FIX: Remove deprecated 'autocast' from torch.cuda.amp
from torch.cuda.amp import GradScaler
from tqdm.auto import tqdm
import logging
from pathlib import Path
from transformers import get_scheduler
from typing import Optional
from transformers import PreTrainedTokenizerBase
# from logging import Logger # FIX: Removed unused import

# اطمینان حاصل کنید که این import ها به درستی کار می‌کنند
try:
    from .configuration import YsnrfdConfig
except ImportError:
    # FIX: Changed Logger.warning to logging.warning
    logging.warning("Could not perform relative import. Please ensure 'ysnrfd' is a package.")
    # Fallback for script-based execution (less ideal)
    # from modeling import YsnrfdForCausalLM
    # from configuration import YsnrfdConfig
try:
    from torch.amp import GradScaler
except ImportError:
    from torch.cuda.amp import GradScaler

try:
    from .modeling import YsnrfdForCausalLM
except ImportError:
    logging.warning("Could not perform relative import. Please ensure 'ysnrfd' is a package.")

logger = logging.getLogger(__name__)


logger = logging.getLogger(__name__)
# FIX: Removed logging.basicConfig(). 
# This should be configured at the application entry point, not in a library file.

class Trainer:
    """
    A simple trainer class for Ysnrfd model with full features:
    - Gradient accumulation
    - Automatic Mixed Precision (AMP)
    - Checkpoint saving/resuming
    - Step-based and Epoch-based saving
    - Early stopping
    
    Args:
        model (`YsnrfdForCausalLM`): The model to train.
        train_dataloader (`DataLoader`): The training data loader.
        optimizer (`torch.optim.Optimizer`): The optimizer to use.
        device (`torch.device`): The device to train on.
        output_dir (`str`): The directory to save the model and checkpoints.
        eval_dataloader (`DataLoader`, *optional*): The evaluation data loader.
        lr_scheduler (`torch.optim.lr_scheduler._LRScheduler`, *optional*): The learning rate scheduler.
        num_epochs (`int`, *optional*, defaults to 3): Number of training epochs.
        max_grad_norm (`float`, *optional*, defaults to 1.0): Gradient clipping.
        use_amp (`bool`, *optional*, defaults to `True`): Whether to use Automatic Mixed Precision.
        gradient_accumulation_steps (`int`, *optional*, defaults to 1): Number of steps to accumulate gradients.
        early_stopping_patience (`int`, *optional*, defaults to 0): 
            Number of epochs with no improvement to wait before stopping. 0 disables early stopping.
        save_strategy (`str`, *optional*, defaults to "epoch"): 
            Strategy for saving checkpoints ("epoch" or "steps").
        save_steps (`int`, *optional*, defaults to 500): 
            Number of global steps between saves if save_strategy="steps".
        log_steps (`int`, *optional*, defaults to 100): 
            Number of global steps between logging training loss. 0 disables step logging.
        resume_from_checkpoint (`Optional[str]`, *optional*): 
            Path to a checkpoint directory to resume training from. 
            Note: The model weights should *already* be loaded into the `model` object passed to this class.
            This will only load optimizer, scheduler, scaler, and step/epoch counts.
        local_rank (`int`, *optional*, defaults to -1): 
            Local rank for distributed training (currently unused, but kept for compatibility).
    """
    def __init__(
        self,
        model: YsnrfdForCausalLM,
        train_dataloader: DataLoader,
        optimizer: torch.optim.Optimizer,
        device: torch.device,
        output_dir: str,
        tokenizer: Optional['PreTrainedTokenizerBase'] = None,
        eval_dataloader: Optional[DataLoader] = None,
        lr_scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None,
        num_epochs: int = 3,
        max_grad_norm: float = 1.0,
        use_amp: bool = True,
        gradient_accumulation_steps: int = 1,
        early_stopping_patience: int = 0,
        save_strategy: str = "epoch",
        save_steps: int = 500,
        log_steps: int = 100,
        resume_from_checkpoint: Optional[str] = None,
        local_rank: int = -1
    ):
        self.model = model.to(device)
        self.train_dataloader = train_dataloader
        self.eval_dataloader = eval_dataloader
        self.optimizer = optimizer
        self.lr_scheduler = lr_scheduler
        self.device = device
        self.output_dir = Path(output_dir)
        self.tokenizer = tokenizer
        self.num_epochs = num_epochs
        self.max_grad_norm = max_grad_norm
        self.use_amp = use_amp and device.type == 'cuda'
        self.gradient_accumulation_steps = max(1, gradient_accumulation_steps)
        self.early_stopping_patience = early_stopping_patience
        self.save_strategy = save_strategy
        self.save_steps = save_steps
        self.log_steps = log_steps
        self.resume_from_checkpoint_path = resume_from_checkpoint
        self.local_rank = local_rank
        
        self.scaler = GradScaler() if self.use_amp else None
        
        # State tracking
        self.global_step = 0
        self.start_epoch = 0
        self.current_epoch = 0
        self.best_eval_loss = float('inf')
        self.epochs_no_improve = 0
        
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Load checkpoint if provided
        self._load_checkpoint()

    def _save_checkpoint(self, checkpoint_dir: Path):
        """
        Saves the model's state, tokenizer, and trainer state to a specified directory.
        """
        # Ensure the directory exists
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Saving checkpoint to {checkpoint_dir}")
        
        try:
            # 1. Unwrap the model (handling DataParallel or DDP wrappers)
            model_to_save = self.model.module if hasattr(self.model, "module") else self.model

            # 2. Save Model Weights & Config
            # safe_serialization=False is CRITICAL for custom models with tied weights 
            # to avoid "tensor shared" errors or silent failures.
            model_to_save.save_pretrained(
                checkpoint_dir, 
                safe_serialization=False, 
                config=model_to_save.config
            )
            
            # 3. Save Tokenizer
            if self.tokenizer:
                self.tokenizer.save_pretrained(checkpoint_dir)

            # 4. Save Trainer State (Optimizer, Scheduler, Steps)
            # This is essential for resuming training correctly.
            trainer_state = {
                'optimizer': self.optimizer.state_dict(),
                'lr_scheduler': self.lr_scheduler.state_dict() if self.lr_scheduler else None,
                'scaler': self.scaler.state_dict() if self.scaler else None,
                'epoch': self.current_epoch,
                'global_step': self.global_step,
                'best_eval_loss': self.best_eval_loss,
                'epochs_no_improve': self.epochs_no_improve,
            }
            torch.save(trainer_state, checkpoint_dir / "trainer_state.pt")
            
            logger.info(f"Checkpoint successfully saved at {checkpoint_dir}")
            
        except Exception as e:
            logger.error(f"CRITICAL: Failed to save model checkpoint: {e}", exc_info=True)
            raise

    def _load_checkpoint(self):
        """Loads trainer state from a checkpoint directory."""
        if self.resume_from_checkpoint_path is None:
            return
            
        checkpoint_path = Path(self.resume_from_checkpoint_path)
        trainer_state_path = checkpoint_path / "trainer_state.pt"
        
        if not trainer_state_path.exists():
            logger.warning(
                f"Trainer state file {trainer_state_path} not found. "
                f"Only model weights are loaded. Starting training state from scratch."
            )
            return

        logger.info(f"Resuming trainer state from: {trainer_state_path}")
        try:
            trainer_state = torch.load(trainer_state_path, map_location=self.device)
            
            self.optimizer.load_state_dict(trainer_state['optimizer'])
            
            if self.lr_scheduler and trainer_state['lr_scheduler']:
                self.lr_scheduler.load_state_dict(trainer_state['lr_scheduler'])
                
            if self.use_amp and self.scaler and trainer_state['scaler']:
                self.scaler.load_state_dict(trainer_state['scaler'])
                
            self.global_step = trainer_state['global_step']
            self.start_epoch = trainer_state['epoch'] + 1 
            self.best_eval_loss = trainer_state.get('best_eval_loss', float('inf'))
            self.epochs_no_improve = trainer_state.get('epochs_no_improve', 0)
            
            logger.info(f"Resumed trainer state. Starting from epoch {self.start_epoch}, global step {self.global_step}.")

        except Exception as e:
            logger.error(f"Failed to load trainer state: {e}. Starting from scratch.")
            self.global_step = 0
            self.start_epoch = 0
            self.best_eval_loss = float('inf')
            self.epochs_no_improve = 0
    
    def train_epoch(self):
        """Trains the model for one epoch."""
        self.model.train()
        total_loss = 0
        
        progress_bar = tqdm(self.train_dataloader, desc=f"Training Epoch {self.current_epoch + 1}", leave=False)
        
        for step, batch in enumerate(progress_bar):
            batch = {k: v.to(self.device) for k, v in batch.items()}
            
            # Forward pass
            # Modern AMP usage
            with torch.amp.autocast(device_type=self.device.type, enabled=self.use_amp):
                outputs = self.model(**batch)
                loss = outputs.loss
                
                if self.gradient_accumulation_steps > 1:
                    loss = loss / self.gradient_accumulation_steps
            
            # Backward pass
            if self.use_amp:
                self.scaler.scale(loss).backward()
            else:
                loss.backward()
            
            # Store unnormalized loss for reporting
            batch_loss = loss.item() * self.gradient_accumulation_steps
            total_loss += batch_loss
            
            # Update weights
            if (step + 1) % self.gradient_accumulation_steps == 0 or (step + 1) == len(self.train_dataloader):
                if self.use_amp:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                else:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                    self.optimizer.step()
                
                if self.lr_scheduler is not None:
                    self.lr_scheduler.step()
                
                self.optimizer.zero_grad()
                self.global_step += 1
                
                # Log step loss
                if self.log_steps > 0 and self.global_step % self.log_steps == 0:
                    logger.info(f"Epoch: {self.current_epoch + 1}, Step: {self.global_step}, Loss: {batch_loss:.4f}, LR: {self.optimizer.param_groups[0]['lr']:.7f}")

                # Save step checkpoint
                if self.save_strategy == "steps" and self.global_step % self.save_steps == 0:
                    self._save_checkpoint(self.output_dir / f"checkpoint-step-{self.global_step}")

            progress_bar.set_postfix({'loss': batch_loss, 'step': self.global_step})
        
        avg_loss = total_loss / len(self.train_dataloader)
        return avg_loss

    def evaluate(self):
        """Evaluates the model on the evaluation set and calculates perplexity."""
        if self.eval_dataloader is None:
            return None, None
        
        self.model.eval()
        total_loss = 0
        total_tokens = 0
        
        with torch.no_grad():
            for batch in tqdm(self.eval_dataloader, desc="Evaluating", leave=False):
                batch = {k: v.to(self.device) for k, v in batch.items()}
                outputs = self.model(**batch)
                
                shift_logits = outputs.logits[..., :-1, :].contiguous()
                shift_labels = batch['input_ids'][..., 1:].contiguous()
                
                pad_token_id = self.model.config.pad_token_id if self.model.config.pad_token_id is not None else -100
                loss_mask = (shift_labels != pad_token_id).float()
                
                loss_fct = torch.nn.CrossEntropyLoss(reduction='none')
                token_loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
                token_loss = token_loss.view(shift_labels.shape) * loss_mask
                
                total_loss += token_loss.sum().item()
                total_tokens += loss_mask.sum().item()
        
        if total_tokens == 0:
            return float('inf'), float('inf')
            
        avg_loss = total_loss / total_tokens
        perplexity = torch.exp(torch.tensor(avg_loss))
        
        return avg_loss, perplexity

    def train(self):
        """Runs the full training loop."""
        logger.info(f"--- Starting training ---")
        logger.info(f"  Num epochs = {self.num_epochs}")
        logger.info(f"  Device = {self.device}")
        logger.info(f"  Save Strategy = {self.save_strategy}")
        
        for epoch in range(self.start_epoch, self.num_epochs):
            self.current_epoch = epoch
            logger.info(f"--- Epoch {epoch+1}/{self.num_epochs} ---")
            
            # --- Training ---
            train_loss = self.train_epoch()
            logger.info(f"Average training loss for epoch {epoch+1}: {train_loss:.4f}")
            
            # --- Evaluation ---
            eval_loss, perplexity = self.evaluate()
            
            if eval_loss is not None:
                logger.info(f"Epoch {epoch+1} Eval Loss: {eval_loss:.4f}, Perplexity: {perplexity:.2f}")
                
                if eval_loss < self.best_eval_loss:
                    self.best_eval_loss = eval_loss
                    self.epochs_no_improve = 0
                    self._save_checkpoint(self.output_dir / "best_model")
                    logger.info(f"New best model saved (Loss: {self.best_eval_loss:.4f})")
                else:
                    self.epochs_no_improve += 1
                
                if self.early_stopping_patience > 0 and self.epochs_no_improve >= self.early_stopping_patience:
                    logger.info("Early stopping triggered.")
                    break
            
            # --- Save checkpoint (Epoch) ---
            if self.save_strategy == "epoch":
                self._save_checkpoint(self.output_dir / f"checkpoint-epoch-{epoch+1}")
        
        # --- Final Model Save ---
        logger.info("Training finished. Saving final model.")
        self._save_checkpoint(self.output_dir / "final_model")